# Especificação do Projeto

Este documento detalha as especificações técnicas ou funcionais detalhadas que descrevem os requisitos e o comportamento esperado do projeto.

## Requisitos 

[**Documento de requisitos**](https://docs.google.com/document/d/1yN_2HuOaRy4tK6O9sWAKt__eSy7wO7Uk/edit?usp=sharing&ouid=113490380921441532168&rtpof=true&sd=true) - Este documento oficializa os requisitos funcionais, requisitos não funcionais e define o escopo do Sistema de Gestão de Feedback Acadêmico.

[**Documento de Cartões 3C**](https://docs.google.com/document/d/1IokB2DgR4RUB99US80G5Jp0F5gCXG2kQLY3lti7HHYA/edit?usp=sharing) - Este documento oficializa os cartões 3c dos requisitos funcionais e não funcionais.
