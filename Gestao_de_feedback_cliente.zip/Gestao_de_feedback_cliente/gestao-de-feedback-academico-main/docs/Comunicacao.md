# Comunicação do Projeto

Este arquivo serve como central para toda a documentação de comunicação do projeto, incluindo registros de conversas com o cliente e outras comunicações relevantes.


## Conversa Inicial com o Cliente

[**Documento da conversa inicial com o cliente**](https://docs.google.com/document/d/1OBPh3uR5X1jKBdX45-elyWasPMvnaSjWoP-b2zDbRCg/edit?usp=sharing) - Este documento proporciona uma compreensão clara das necessidades e requisitos do cliente. Ele serve como guia para o lavantamento de requisitos do sistema.
