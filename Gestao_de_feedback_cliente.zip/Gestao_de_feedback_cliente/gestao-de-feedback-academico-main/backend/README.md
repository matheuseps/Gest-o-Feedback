# gestao-de-feedback-academico
Gestão de Feedback Acadêmico é um sistema que gerencia os feedbacks dos alunos sobre as aulas e atividades realizadas durante a disciplina de Programação Orientada a Objetos.
