package com.gestao.feedback_academico.domain.dto;

public record AuthRequest(String email, String senha) {
}
