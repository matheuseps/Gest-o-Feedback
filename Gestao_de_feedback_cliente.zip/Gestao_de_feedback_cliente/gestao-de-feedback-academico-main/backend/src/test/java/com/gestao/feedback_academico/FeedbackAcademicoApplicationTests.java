package com.gestao.feedback_academico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackAcademicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
