import { useState } from "react";

const CriarProfessor = () =>{

    const aula = {turmaId:1, dataOcorreu:date, descricao:""}

    return(
        <div className="page-content">
           
        </div>
    )
}

export default CriarProfessor;